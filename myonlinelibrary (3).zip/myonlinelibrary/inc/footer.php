<html>
<head>
<title><?php echo $pageTitle; ?></title>
<link rel="stylesheet" href="css/style.css" type="text/css">
</head>
<body>
<div class="footer">
<div class="wrapper">
<ul>
<li><a href="#">Twitter</a></li>
<li><a href="#">Facebook</a></li>
</ul>
<p>&copy;<?php echo date("Y"); ?>My Online Library</p>
    </div>
    </div>
</body>
</html>